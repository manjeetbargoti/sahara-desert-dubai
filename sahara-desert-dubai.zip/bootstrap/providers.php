<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\RouteServiceProvider::class,
    Maatwebsite\Excel\ExcelServiceProvider::class,
];
