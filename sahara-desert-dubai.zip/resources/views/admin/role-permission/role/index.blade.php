@extends("admin.layouts.main")
@section("content")

<div class="components-preview wide-lg mx-auto">
    <div class="nk-block nk-block-lg">
        <div class="nk-block-head">
            <div class="nk-block-between">
                <div class="nk-block-head-content">
                    <h4 class="nk-block-title">Roles List</h4>
                </div>
                <div class="nk-block-head-content">
                    <a href="{{ route('admin.roles.create') }}" class="btn btn-primary"><em class="icon ni ni-plus"></em><span>Add Role</span></a>
                </div>
            </div>
        </div>

        @if(session('success'))
        <div class="alert alert-success alert-icon">
            <em class="icon ni ni-check-circle"></em> {{ session('success') }}
        </div>
        @endif
        @if(session('error'))
        <div class="alert alert-danger alert-icon">
            <em class="icon ni ni-check-circle"></em> {{ session('error') }}
        </div>
        @endif

        <div class="card card-bordered card-preview">
            <table class="table table-tranx">
                <thead>
                    <tr class="tb-tnx-head">
                        <th class="tb-tnx-id"><span class="">#</span></th>
                        <th class="tb-tnx-info">
                            <span class="tb-tnx-desc">
                                <span>Name</span>
                            </span>
                            <span class="tb-tnx-desc">
                                <span>User Type</span>
                            </span>
                        </th>
                        <th class="tb-tnx-amount is-alt">
                            <span class="tb-tnx-status d-none d-md-inline-block">Status</span>
                        </th>
                        <th class="tb-tnx-action">
                            <span>&nbsp;</span>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($roles as $key => $role)
                    <tr class="tb-tnx-item">
                        <td class="tb-tnx-id">
                            <span>{{ ($key+1) + ($roles->currentPage() - 1)*$roles->perPage() }}</span>
                        </td>
                        <td class="tb-tnx-info">
                            <div class="tb-tnx-desc">
                                <span class="title">{{ @$role->name }}</span>
                            </div>
                            <div class="tb-tnx-desc">
                                <span class="title">{{ @$role->user_type }}</span>
                            </div>
                        </td>
                        <td class="tb-tnx-amount is-alt">
                            <div class="tb-tnx-status">
                                @if(@$role->status == 1)
                                <span class="badge badge-dot badge-success">{{ __('Active') }}</span>
                                @else
                                <span class="badge badge-dot badge-danger">{{ __('Inactive') }}</span>
                                @endif
                            </div>
                        </td>
                        <td class="tb-tnx-action">
                            <div class="dropdown">
                                <a class="text-soft dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                <div class="dropdown-menu dropdown-menu-right dropdown-menu-xs">
                                    <ul class="link-list-plain">
                                        <li><a href="{{ route('admin.permissions.update', @$role->id) }}" class="text-info">{{ __('Update Permissions') }}</a></li>
                                        <li><a href="{{ route('admin.roles.edit', @$role->id) }}" class="text-primary">{{ __('Edit') }}</a></li>
                                        <li><a href="{{ route('admin.role.delete', @$role->id) }}" class="text-danger">{{ __('Delete') }}</a></li>
                                    </ul>
                                </div>
                            </div>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div><!-- .card-preview -->
    </div><!-- nk-block -->
</div><!-- .components-preview -->

@endsection